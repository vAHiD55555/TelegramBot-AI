# TelegramBot-AI
A telegram bot that uses gemini ai


![image](https://github.com/user-attachments/assets/b52c9c79-e340-4c87-93c0-248215a4faba)
